function Solution = LocalSearch(Pop,D,M,Problem)
N = length(Pop);
Solution = [];
for i=1:N
    Parent = Pop(i).domains;
    Solution = [Solution Parent];
end
Solution = OperatorGA(Problem,Solution);
end