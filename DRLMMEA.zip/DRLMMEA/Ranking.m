function [Population, CrowdDis] = Ranking(Population, N)

    n = length(Population);

    %% Cal the local convergence
    dist = pdist2(Population.decs, Population.decs);
    V = 0.2 * prod(max(Population.decs) - min(Population.decs))^(1 / size(Population.decs, 2));

    DominationX = zeros(n);  % Pareto domination relationship between pairs of solutions
    for i = 1:n
        for j = i + 1:n
            if dist(i, j) > V
                continue;
            end
            L1 = Population(i).objs < Population(j).objs;
            L2 = Population(i).objs > Population(j).objs;
            if all(L1 | (~L2))
                DominationX(i, j) = 0;
                DominationX(j, i) = 1;
            elseif all(L2 | (~L1))
                DominationX(i, j) = 1;
                DominationX(j, i) = 0;
            end
        end
    end

    % Step 1: Calculate weighted local convergence measure
    LocalC = zeros(1, n);
    for i = 1:n
        tmp = dist(i, :);
        index = tmp < V;  % Find individuals within the neighborhood (distance < V)
        
        % Calculate weighted domination: closer individuals have higher weight
        weights = exp(-tmp(index));  % Using an exponential decay function for distance-based weight
        
        % Weighted sum of domination relationships
        LocalC(i) = sum(weights .* DominationX(i, index)) / sum(weights);
    end

    % Step 2: Calculate the crowding distance (you can keep the previous method)
    dist = sort(pdist2(Population.decs, Population.decs));
    CrowdDis = sum(dist(1:3, :));

    % Step 3: Sort based on LocalC and CrowdDis (to balance both convergence and diversity)
    [~, index] = sortrows([LocalC' -CrowdDis']);
    Population = Population(index);

    % Step 4: Keep the top N individuals
    if length(Population) > N
        Population = Population(1:N);
    end

    % Step 5: Calculate final crowding distance for selected population
    CrowdDis = Crowding(Population.decs);
  
end
