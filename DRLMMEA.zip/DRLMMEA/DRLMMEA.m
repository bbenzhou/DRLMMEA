classdef DRLMMEA< ALGORITHM
% <multi> <real/integer/label/binary/permutation> <multimodal>
% This is a simple demo of MMODE_SPDN
% div --- 10 --- Parameter for quality of the local Pareto front
% K --- 10 --- Parameter for quality of the local Pareto front

%------------------------------- Reference --------------------------------
% If you find this code useful in your work, please cite the 
% following paper "H. Peng, W. Xia, Z. Luo, C. Deng, H. Wang, Z. Wu, A multimodal multi-objective 
% differential evolution with series-parallel combination and dynamic neighbor strategy, 
% Information Sciences,2024".
%------------------------------- Copyright --------------------------------
% Copyright (c) 2024 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------
    methods
        function main(Algorithm,Problem)
            %% Parameter setting
            div = Algorithm.ParameterSet(10);
%            OS_neighbourhood = 25;
            K=10;
            eps = Algorithm.ParameterSet(0.3);
             %% For DQL
            Data = [];
            num_operator = 3;
            model_built = 0;
            count = 0;
            greedy = 0.95;
            gama = 0.9;
            %% Generate random population
            Population = Problem.Initialization();
            [W,Problem.N] = UniformPoint(Problem.N,Problem.M);
            W = W./repmat(sqrt(sum(W.^2,2)),1,size(W,2));
            Z          = min(Population.objs,[],1);
            [Pbest,Gbest] = GetBest(Population,W,Z);
            %% calculate fitness of populations
          %  [Fitness,D_Dec,~] = CalFitness(Population.objs,Population.decs);
            %% Generate random population
            Population1 = Problem.Initialization();
            N = length(Population);
            temp1=Population;
            temp2=Population;
            EvoState = Problem.FE / Problem.maxFE;
            [FrontNo,~] = NDSort(Population.objs,N);
            BA = Population(FrontNo(1:N));
            [DA,CrowdDis2] = ArchiveUpdate(temp2,N,eps,0);
            [CrowdDis,CrowdDec,~] = CrowdingDistance(Population.decs,Population.objs,FrontNo);
            [SubPopulation,~] = Partition(BA,K);
            ADA = SubPopulation;
            %% Optimization
             while Algorithm.NotTerminated(Population1)
            gen = ceil(Problem.FE/(2*Problem.N));
            average_d =calculateEntropy(Population);
            average_c = calLocalC(Population);
                if gen <= 200
                    %% Exploring stage, choose operator randomly
                    operator = randi(num_operator);
                else
                    %% Learning stage, choose by Deep Q-net
                    % choose an action based on the trained net
                    if ~model_built
                        % build model here
                        use_data = randperm(length(Data),200);
                        tr_x = Data(use_data,1:3);
                        [tr_xx,ps] = mapminmax(tr_x');tr_xx=tr_xx';
                        tr_y = Data(use_data,4:6);
                        [tr_yy,qs] = mapminmax(tr_y');tr_yy=tr_yy';
                        Params.ps  = ps;Params.qs=qs;
                        [net,Params] = trainmodel(tr_xx,tr_yy,Params);
                        model_built = 1;
                        operator = randi(num_operator);
                    else
                        % use the model to choose action
                        if rand > greedy
                            operator = randi(num_operator);
                        else
                           test_x1 = [average_c,average_d,1];
                           test_x2 = [average_c,average_d,2];
                            ps=Params.ps;
                            qs=Params.qs;
                            x1=mapminmax('apply',test_x1',ps);x1=x1';
                            x2=mapminmax('apply',test_x2',ps);x2=x2';
                            reward = testNet(x1,net,Params);
                            reward=mapminmax('reverse',reward',qs);reward=reward';
                            succ2 = testNet(x2,net,Params);
                            succ2=mapminmax('reverse',succ2',qs);succ2=succ2';
                            succ = [reward;succ2];
                            [~,operator] = max(succ(:,1));
                        end
                    end
                end

                 Offspring1 = LocalSearch(ADA,Problem.D,Problem.M,Problem);
                 Combination = [BA,Offspring1];
                % MatingPoolAA = Selection(temp1,OS_neighbourhood,CrowdDis,CrowdDec);
                 %AA=Dynamic_neighbor_based_mutation(Problem,temp1(MatingPoolAA(:,1)),temp1(MatingPoolAA(:,2)),temp1(MatingPoolAA(:,3)),temp1(MatingPoolAA(:,4)),{0.1, 0.5, 1, 15});
                % AA = OperaPSO(Problem,temp1,Pbest,Gbest);
                 MatingPoolCA = MatingSelection(temp2.decs,div);
                 if operator == 1
                       Offspring3 = OperatorGA(Problem,temp2(MatingPoolCA));
                 else
                       Offspring3=DEgenerator2(Problem,temp2);
                 end
                 CA = GrEA([Population,Offspring3],N,div);
                 MatingPool2 = TournamentSelection(2,round(N),-CrowdDis2);
                 Offspring2  = OperatorGAhalf(Problem,DA(MatingPool2));
                 BA = CSCD_ArchiveUpdate(Combination,N);
                 [DA,CrowdDis2]    = Ranking([DA,Offspring2,CA],N);
                 Offspring  = OperatorGAhalf(Problem,Population(MatingPool2));
                % Offspring  = Operator(Problem,Population,K);
                 temp3=[BA,CA,DA];
              %   Population1 = EnvironmentalSelection2([temp3,Offspring,Population1],Problem.N);
               Population1 = EnvironmentalSelection2([temp3,Offspring,Population1],N*1.5,'Normal',EvoState);
                 Population = EnvironmentalSelection1([temp3,Offspring,Population1],N);
                 % new stage
                average_d1 =calculateEntropy(Population);
                average_c1 = calLocalC(Population);
                %% Update experience replay
                reward = (average_c1 + average_d1) - (average_c + average_d);
                current_record = [average_c average_d operator reward average_c1 average_d1];
                Data = [Data;current_record];
                if size(Data,1) > 500
                    Data(end,:) = [];
                end

                %% Update Q-net
                % update net model every 50 generations
                if model_built
                    count = count + 1;
                    if count > 50
                        % update model here
                        qs=Params.qs;
                        use_data = randperm(length(Data),200);
                        tr_x = Data(use_data,1:3);
                        [tr_xx,ps] = mapminmax(tr_x');tr_xx=tr_xx';
                        reward = testNet(tr_xx,net,Params);
                        reward=mapminmax('reverse',reward',qs);reward=reward';
                        succ = reward(:,1);
                        tr_yy = Data(use_data,4)+gama*max(succ);
                        [tr_yy,qs] = mapminmax(tr_yy');tr_yy=tr_yy';
                        Params.ps  = ps;Params.qs=qs;
                        net = updatemodel(tr_xx,tr_yy,Params,net);
                        count = 0;
                    end
                end
             end
         end
    end
end
function entropy_value = calculateEntropy(population)
    
    N = size(population, 1);  % 个体数量
    M = size(population, 2);  % 目标数量
    % Step 1: 计算个体之间的距离矩阵（使用欧氏距离）
    distances = zeros(N, N);  % 距离矩阵
    for i = 1:N
        for j = i+1:N
            % 计算欧氏距离
            dist = sqrt(sum((population(i,:) - population(j,:)).^2));
            distances(i,j) = dist;
            distances(j,i) = dist;  % 距离是对称的
        end
    end
    upper_triangle = triu(distances, 1);  % 去除对角线部分，只保留上三角
    entropy_value = sum(upper_triangle(:));  % 对上三角部分的所有元素求和
end

function sumLocalC = calLocalC(Population)
       n = length(Population);

    %% Cal the local convergence
    dist = pdist2(Population.decs, Population.decs);
    V = 0.2 * prod(max(Population.decs) - min(Population.decs))^(1 / size(Population.decs, 2));

    DominationX = zeros(n);  % Pareto domination relationship between pairs of solutions
    for i = 1:n
        for j = i + 1:n
            if dist(i, j) > V
                continue;
            end
            L1 = Population(i).objs < Population(j).objs;
            L2 = Population(i).objs > Population(j).objs;
            if all(L1 | (~L2))
                DominationX(i, j) = 0;
                DominationX(j, i) = 1;
            elseif all(L2 | (~L1))
                DominationX(i, j) = 1;
                DominationX(j, i) = 0;
            end
        end
    end

    % Step 1: Calculate weighted local convergence measure
    LocalC = zeros(1, n);
    for i = 1:n
        tmp = dist(i, :);
        index = tmp < V;  % Find individuals within the neighborhood (distance < V)
        
        % Weighted sum of domination relationships
        LocalC(i) = sum(DominationX(i, index));
    end
    sumLocalC = sum(LocalC);
end