function Offspring = OperaPSO(Problem, Particle, Pbest, Gbest)
    % Particle swarm optimization in MMOPSO with enhanced diversity and adaptability

    %------------------------------- Copyright --------------------------------
    % Copyright (c) 2024 BIMK Group. You are free to use the PlatEMO for
    % research purposes. All publications which use this platform or any code
    % in the platform should acknowledge the use of "PlatEMO" and reference "Ye
    % Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
    % for evolutionary multi-objective optimization [educational forum], IEEE
    % Computational Intelligence Magazine, 2017, 12(4): 73-87".
    %--------------------------------------------------------------------------

    %% Parameter setting
    ParticleDec = Particle.decs;  % Current decision variables
    PbestDec = Pbest.decs;       % Personal best decision variables
    GbestDec = Gbest.decs;       % Global best decision variables
    [N, D] = size(ParticleDec);  % N: population size, D: dimension
    ParticleVel = Particle.adds(zeros(N, D));  % Initial velocity

    %% Adaptive parameter setting (W, C1, C2)
    % Dynamically adjust inertia weight (W) and cognitive & social coefficients (C1, C2)
    W_min = 0.4; W_max = 0.9; % Inertia weight range
    C1_min = 1.5; C1_max = 2.0; % Cognitive coefficient range
    C2_min = 1.5; C2_max = 2.0; % Social coefficient range
    
    % Adaptive inertia weight (W) based on iteration progress or diversity
    W = repmat(unifrnd(W_min, W_max, N, 1), 1, D);
    
    % Adaptive coefficients C1, C2 based on distance from personal best or global best
    dist_pbest = sqrt(sum((ParticleDec - PbestDec).^2, 2));  % Distance from personal best
    dist_gbest = sqrt(sum((ParticleDec - GbestDec).^2, 2));  % Distance from global best
    
    % Inverse distance-based adaptation (larger distance, larger influence)
    C1 = repmat(C1_min + (C1_max - C1_min) * (dist_pbest / max(dist_pbest)), 1, D);
    C2 = repmat(C2_min + (C2_max - C2_min) * (dist_gbest / max(dist_gbest)), 1, D);

    %% Velocity update (PSO update equation)
    r1 = rand(N, D);  % Random factors
    r2 = rand(N, D);
    
    % Calculate velocity for particles based on personal best and global best
    OffVel = W .* ParticleVel;  % Inertia component
    temp = rand(N, 1) < 0.7;    % Random selection mechanism for exploration/exploitation

    % Update velocity for particles based on personal best or global best
    OffVel(temp) = OffVel(temp) + C1(temp) .* r1(temp) .* (PbestDec(temp) - ParticleDec(temp));
    OffVel(~temp) = OffVel(~temp) + C2(~temp) .* r2(~temp) .* (GbestDec(~temp) - ParticleDec(~temp));

    %% Apply velocity limits (to prevent excessive velocity values)
    max_velocity = 0.1 * (max(ParticleDec) - min(ParticleDec));
    OffVel = min(max(OffVel, -max_velocity), max_velocity);

    %% Position update
    OffDec = ParticleDec + OffVel;  % Update decision variables

    %% Diversity enhancement - Crowding distance calculation (to maintain diversity)
    Offspring = Problem.Evaluation(OffDec, OffVel);  % Evaluate new solutions
    
    % Apply crowding distance mechanism here if needed
    % For example, you can calculate the crowding distance and select based on diversity

    % Return the updated offspring
end
